#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

sem_t mutex;//mutex = veh�culo.

void* thread(void* arg)
{
	srand(time(NULL));//Semilla al azar inicializada.
	int x = rand() % 6 + 1;//Posici�n de 1 a 6.
	int vehiculo = 10;//Cantidad de veh�culos.
    
    int Pizza1 = 1;
    int Pizza2 = 2;
    int Sandwich = 3;
    int Sushi1 = 4;
    int Sushi2 = 5;

	int espera = rand() % 2 + 1;//F�rmula de espera de 1 a 2 segundos para que llegue un pedido.
	printf("\nEntrando pedido... %d segundos de espera...\n", espera);//Entra el pedido.
    sleep(espera);//El veh�culo espera 1 o 2 segundos para que llegue el pedido.
	if(x == Pizza1)
    {
       	//wait
    	sem_wait(&mutex);//El veh�culo espera el pedido, que es nuestro sem�foro.
    	int buffer_local = 10;//Buffer local que almacena 10 elementos (pedidos).
       	while(buffer_local > 0)
    	{
    		printf("\nSaliendo pedido de Pizza1.\n");
        	//critical section
        	printf("\nPizza1:\n-Buffer local = %d\n", buffer_local-3);
        	buffer_local = buffer_local - 3;
		}
       	//signal
    	printf("\nYa no hay mas alimentos en Pizza1.\n");
    	sem_post(&mutex);//Libera el sem�foro veh�culo al darle un se�al.
    }
    else if(x == Pizza2)
    {
    	//wait
    	sem_wait(&mutex);//El veh�culo espera el pedido, que es nuestro sem�foro.
    	int buffer_local = 8;//Buffer local que almacena 10 elementos (pedidos).
    	while(buffer_local > 0)
    	{
    		printf("\nSaliendo pedido de Pizza2.\n");
        	//critical section
        	printf("\nPizza2:\n-Buffer local = %d\n", buffer_local-3);
        	buffer_local = buffer_local - 3;
    	}
    	//signal
    	printf("\nYa no hay mas alimentos en Pizza2.\n");
    	sem_post(&mutex);//Libera el sem�foro veh�culo al darle un se�al.
    }
    else if(x == Sandwich)
    {
    	//wait
    	sem_wait(&mutex);//El veh�culo espera el pedido, que es nuestro sem�foro.
    	int buffer_local = 6;//Buffer local que almacena 10 elementos (pedidos).
    	while(buffer_local > 0)
    	{
    		printf("\nSaliendo pedido de Sandwich.\n");
        	//critical section
        	printf("\nSandwich:\n-Buffer local = %d\n", buffer_local-3);
        	buffer_local = buffer_local - 3;
    	}
    	//signal
    	printf("\nYa no hay mas alimentos en Sandwich.\n");
    	sem_post(&mutex);//Libera el sem�foro veh�culo al darle un se�al.
    }
    else if(x == Sushi1)
    {
    	//wait
    	sem_wait(&mutex);//El veh�culo espera el pedido, que es nuestro sem�foro.
    	int buffer_local = 12;//Buffer local que almacena 10 elementos (pedidos).
    	while(buffer_local > 0)
    	{
    		printf("\nSaliendo pedido de Sushi1.\n");
        	//critical section
        	printf("\nSushi1:\n-Buffer local = %d\n", buffer_local-3);
        	buffer_local = buffer_local - 3;
    	}
    	//signal
    	printf("\nYa no hay mas alimentos en Sushi1.\n");
    	sem_post(&mutex);//Libera el sem�foro veh�culo al darle un se�al.
    }
    else if(x == Sushi2)
    {
    	//wait
    	sem_wait(&mutex);//El veh�culo espera el pedido, que es nuestro sem�foro.
    	int buffer_local = 8;//Buffer local que almacena 10 elementos (pedidos).
    	while(buffer_local > 0)
    	{
    		printf("\nSaliendo pedido de Sushi2.\n");
        	//critical section
        	printf("\nSushi2:\n-Buffer local = %d\n", buffer_local-3);
        	buffer_local = buffer_local - 3;
    	}
    	//signal
    	printf("\nYa no hay mas alimentos en Sushi2.\n");
    	sem_post(&mutex);//Libera el sem�foro veh�culo al darle un se�al.
    }
    else
    {
    	printf("\nBuscando local...\n");
    	sem_post(&mutex);//Libera el sem�foro veh�culo al darle un se�al.
	}
}

int main()
{
    sem_init(&mutex, 0, 1);
    pthread_t t1,t2,t3,t4,t5;
    pthread_create(&t1,NULL,thread,NULL);
    pthread_join(t1,NULL);
    pthread_create(&t2,NULL,thread,NULL);
    pthread_join(t2,NULL);
    pthread_create(&t3,NULL,thread,NULL);
    pthread_join(t3,NULL);
    pthread_create(&t4,NULL,thread,NULL);
    pthread_join(t4,NULL);
    pthread_create(&t5,NULL,thread,NULL);
    pthread_join(t5,NULL);
	sem_destroy(&mutex);
    return 0;
}
