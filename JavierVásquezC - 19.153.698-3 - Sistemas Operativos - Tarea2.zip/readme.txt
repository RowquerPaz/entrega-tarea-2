Implementé hasta la parte de 1 de los semáforos. No supe muy bien cómo implementar
el número de vehículos en el programa para se salga del bucle ni cómo evitar que
un vehículo no visite el mismo local cuando ya ha pasado por éste.